export default function DeliveryReports() {
  return (
    <div className="bg-white shadow-lg border-l-8 border-cyan p-8 rounded-xl">
      <h2 className="text-2xl font-bold text-navy mb-4">Relatórios</h2>
      <p className="text-gray-600 text-lg">
        Os relatórios serão adicionados futuramente.
      </p>
    </div>
  );
}
