export default function DeliveryHistory() {
  return (
    <div className="bg-white shadow-lg border-l-8 border-navy p-8 rounded-xl">
      <h2 className="text-2xl font-bold text-navy mb-4">Histórico de Entregas</h2>
      <p className="text-gray-600 text-lg">
        O histórico será implementado futuramente.
      </p>
    </div>
  );
}
